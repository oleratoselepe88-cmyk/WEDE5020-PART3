/* =========================================================
   Sweet Crumb Home Bakery - script.js (Part 3)
   ---------------------------------------------------------
   1.  Helpers (DOM builder, validation helpers)
   2.  Navigation (accessible hamburger menu)
   3.  Scroll-reveal animation + back-to-top button
   4.  Dynamic content: products loaded from data/products.json
       - home page "favourites"
       - menu page with search, filter, sort + quick-view modal
   5.  Enquiry form: validation + AJAX (fetch) quote/availability
   6.  Contact form: validation + compiled email (mailto)
   7.  Contact page: interactive Leaflet map
   8.  About page: tabs, accordion (FAQ), gallery lightbox
   ========================================================= */
'use strict';

/* =========================================================
   1. HELPERS
   ========================================================= */
const $ = (sel, root = document) => root.querySelector(sel);
const $$ = (sel, root = document) => Array.from(root.querySelectorAll(sel));

/**
 * Small DOM builder. Uses textContent (never innerHTML) so data coming from
 * JSON or user input can never inject markup.
 * el('p', { class: 'x', text: 'Hi', attrs: { id: 'a' } }, childNode, ...)
 */
function el(tag, props = {}, ...children) {
  const node = document.createElement(tag);
  if (props.class) node.className = props.class;
  if (props.text !== undefined) node.textContent = props.text;
  if (props.attrs) {
    Object.entries(props.attrs).forEach(([k, v]) => node.setAttribute(k, v));
  }
  children.flat().forEach(c => {
    if (c) node.append(c);
  });
  return node;
}

const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
const money = n => 'R' + Number(n).toFixed(2);

/** Show (or clear) a field error and keep ARIA attributes in sync. */
function setError(fieldId, message) {
  const errBox = document.getElementById('err-' + fieldId);
  const field = document.getElementById(fieldId);
  if (errBox) errBox.textContent = message;
  if (field) {
    if (message) {
      field.setAttribute('aria-invalid', 'true');
      field.setAttribute('aria-describedby', 'err-' + fieldId);
    } else {
      field.removeAttribute('aria-invalid');
      field.removeAttribute('aria-describedby');
    }
  }
}

/**
 * Wire up validation for a form.
 * rules = { fieldId: () => 'error message' | '' }
 * Validates on blur (and on input once a field has been touched) and returns
 * a function that validates everything and focuses the first invalid field.
 */
function attachValidation(rules) {
  const touched = new Set();
  Object.keys(rules).forEach(id => {
    const field = document.getElementById(id);
    if (!field) return;
    field.addEventListener('blur', () => {
      touched.add(id);
      setError(id, rules[id]());
    });
    const live = () => { if (touched.has(id)) setError(id, rules[id]()); };
    field.addEventListener('input', live);
    field.addEventListener('change', live);
  });

  return function validateAll() {
    let firstInvalid = null;
    Object.keys(rules).forEach(id => {
      touched.add(id);
      const msg = rules[id]();
      setError(id, msg);
      if (msg && !firstInvalid) firstInvalid = document.getElementById(id);
    });
    if (firstInvalid) firstInvalid.focus();
    return !firstInvalid;
  };
}

// Shared validation patterns
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
const NAME_RE = /^\p{L}[\p{L}\s'.-]+$/u;
// South African numbers: 0821234567 or +27821234567 (spaces/dashes allowed)
const PHONE_RE = /^(\+27|0)[1-9]\d{8}$/;

const rule = {
  name(id) {
    const v = $('#' + id).value.trim();
    if (v.length < 2) return 'Please enter your full name (at least 2 characters).';
    if (v.length > 60) return 'Name must be 60 characters or fewer.';
    if (!NAME_RE.test(v)) return 'Names can only contain letters, spaces, apostrophes, full stops and hyphens.';
    return '';
  },
  email(id) {
    const v = $('#' + id).value.trim();
    if (!v) return 'Please enter your email address.';
    if (!EMAIL_RE.test(v)) return 'Enter a valid email address, e.g. name@example.com.';
    return '';
  },
  phone(id, required) {
    const v = $('#' + id).value.trim();
    if (!v) return required ? 'Please enter your phone number.' : '';
    if (!PHONE_RE.test(v.replace(/[\s-]/g, ''))) {
      return 'Enter a valid South African number, e.g. 082 123 4567 or +27 82 123 4567.';
    }
    return '';
  },
  required(id, message) {
    return $('#' + id).value ? '' : message;
  }
};

/* =========================================================
   2. NAVIGATION
   ========================================================= */
document.documentElement.classList.add('js');

(function initNav() {
  const header = $('header');
  const btn = $('.hamburger');
  if (!header || !btn) return;

  const setOpen = open => {
    header.classList.toggle('nav-open', open);
    btn.setAttribute('aria-expanded', String(open));
  };

  btn.addEventListener('click', () => setOpen(!header.classList.contains('nav-open')));
  $$('nav a').forEach(a => a.addEventListener('click', () => setOpen(false)));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape' && header.classList.contains('nav-open')) {
      setOpen(false);
      btn.focus();
    }
  });
})();

/* =========================================================
   3. ANIMATIONS: scroll reveal + back-to-top
   ========================================================= */
(function initReveal() {
  const items = $$('.reveal');
  if (!items.length) return;
  if (prefersReducedMotion || !('IntersectionObserver' in window)) return;

  const observer = new IntersectionObserver((entries, obs) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('is-visible');
        obs.unobserve(entry.target);
      }
    });
  }, { threshold: 0.12 });

  items.forEach(item => {
    // Only hide sections that start below the fold, so nothing flashes.
    if (item.getBoundingClientRect().top > window.innerHeight) {
      item.classList.add('reveal-hidden');
      observer.observe(item);
    }
  });
})();

(function initBackToTop() {
  const btn = el('button', {
    class: 'back-to-top',
    text: '\u2191',
    attrs: { type: 'button', 'aria-label': 'Back to top', hidden: '' }
  });
  document.body.append(btn);

  let ticking = false;
  window.addEventListener('scroll', () => {
    if (ticking) return;
    ticking = true;
    window.requestAnimationFrame(() => {
      btn.hidden = window.scrollY < 500;
      ticking = false;
    });
  }, { passive: true });

  btn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: prefersReducedMotion ? 'auto' : 'smooth' });
  });
})();

/* =========================================================
   4. DYNAMIC CONTENT: load products from JSON (AJAX / fetch)
   ========================================================= */
let productsPromise = null;
function loadProductData() {
  if (!productsPromise) {
    productsPromise = fetch('data/products.json', { cache: 'no-store' })
      .then(res => {
        if (!res.ok) throw new Error('HTTP ' + res.status);
        return res.json();
      });
  }
  return productsPromise;
}

function showLoadError(container, message) {
  container.replaceChildren(el('p', {
    class: 'error-note',
    text: message || 'Sorry, we could not load this content right now. Please refresh the page or contact us directly.'
  }));
}

/** Build a product card using DOM methods. */
function createProductCard(p, { quickView } = {}) {
  const img = el('img', {
    attrs: {
      src: `images/${p.image}-800.jpg`,
      srcset: `images/${p.image}-400.jpg 400w, images/${p.image}-800.jpg 800w, images/${p.image}-1200.jpg 1200w`,
      sizes: '(max-width: 640px) 90vw, (max-width: 1024px) 45vw, 260px',
      alt: p.alt,
      width: p.width,
      height: p.height,
      loading: 'lazy'
    }
  });
  const card = el('article', { class: 'card product-card' },
    img,
    el('h3', { text: p.name }),
    el('p', { text: p.description }),
    el('p', { class: 'price', text: (p.priceFrom ? 'From ' : '') + money(p.price) + (p.category === 'boxes' ? '' : ' each') })
  );
  const actions = el('div', { class: 'card-actions' });
  if (quickView) {
    const qv = el('button', { class: 'btn btn-outline btn-small', text: 'Quick view', attrs: { type: 'button' } });
    qv.addEventListener('click', () => quickView(p));
    actions.append(qv);
  }
  actions.append(el('a', { class: 'btn btn-small', text: 'Order', attrs: { href: 'enquiry.html?item=' + encodeURIComponent(p.id) } }));
  card.append(actions);
  return card;
}

/* ---------- Home page: featured products ---------- */
(function initFeatured() {
  const grid = $('#featured-grid');
  if (!grid) return;
  loadProductData()
    .then(data => {
      grid.replaceChildren(...data.products.slice(0, 3).map(p => createProductCard(p)));
    })
    .catch(() => showLoadError(grid, 'Our favourites are taking a moment to load. Please see the menu page.'));
})();

/* ---------- Menu page: search, filter, sort, quick view ---------- */
(function initMenu() {
  const grid = $('#product-grid');
  if (!grid || !$('#product-search')) return;

  const searchInput = $('#product-search');
  const categorySel = $('#product-category');
  const sortSel = $('#product-sort');
  const countEl = $('#result-count');
  const dialog = $('#quick-view');
  let all = [];

  // Pre-fill controls from the URL (?q=almond&category=croissants&sort=price-asc)
  const params = new URLSearchParams(window.location.search);
  if (params.get('q')) searchInput.value = params.get('q');
  if (params.get('category')) categorySel.value = params.get('category');
  if (params.get('sort')) sortSel.value = params.get('sort');

  function openQuickView(p) {
    const body = $('#qv-body');
    body.replaceChildren(
      el('img', { attrs: { src: `images/${p.image}-800.jpg`, alt: p.alt, width: p.width, height: p.height } }),
      el('h2', { text: p.name, attrs: { id: 'qv-title' } }),
      el('p', { text: p.description }),
      el('p', { class: 'price', text: (p.priceFrom ? 'From ' : '') + money(p.price) }),
      el('p', { text: 'Allergens: ' + p.allergens.join(', ') + '.' }),
      el('p', { text: 'Limited to ' + p.maxPerWeekend + ' per weekend.' }),
      el('a', { class: 'btn', text: 'Order this item', attrs: { href: 'enquiry.html?item=' + encodeURIComponent(p.id) } })
    );
    dialog.showModal();
  }

  function render() {
    const term = searchInput.value.trim().toLowerCase();
    const cat = categorySel.value;
    const sort = sortSel.value;

    let list = all.filter(p => {
      const matchesCat = cat === 'all' || p.category === cat;
      const matchesTerm = !term || (p.name + ' ' + p.description + ' ' + p.category).toLowerCase().includes(term);
      return matchesCat && matchesTerm;
    });

    if (sort === 'price-asc') list.sort((a, b) => a.price - b.price);
    else if (sort === 'price-desc') list.sort((a, b) => b.price - a.price);
    else if (sort === 'name-asc') list.sort((a, b) => a.name.localeCompare(b.name));

    countEl.textContent = `Showing ${list.length} of ${all.length} items`;

    if (!list.length) {
      const reset = el('button', { class: 'btn btn-outline btn-small', text: 'Clear filters', attrs: { type: 'button' } });
      reset.addEventListener('click', () => {
        searchInput.value = '';
        categorySel.value = 'all';
        sortSel.value = 'default';
        render();
        searchInput.focus();
      });
      grid.replaceChildren(el('div', { class: 'empty-state' },
        el('p', { text: 'No items match your search. Try a different word or category.' }), reset));
      return;
    }
    grid.replaceChildren(...list.map(p => createProductCard(p, { quickView: openQuickView })));
  }

  let timer;
  searchInput.addEventListener('input', () => {
    clearTimeout(timer);
    timer = setTimeout(render, 150);
  });
  categorySel.addEventListener('change', render);
  sortSel.addEventListener('change', render);
  $('#product-toolbar').addEventListener('submit', e => e.preventDefault());

  // Dialog: close button and click on the backdrop
  dialog.addEventListener('click', e => {
    if (e.target === dialog || e.target.closest('[data-close]')) dialog.close();
  });

  loadProductData()
    .then(data => { all = data.products; render(); })
    .catch(() => showLoadError(grid, 'We could not load the menu. If you opened this file directly from your computer, run it through a local server (e.g. VS Code Live Server) or view the deployed site.'));
})();

/* =========================================================
   5. ENQUIRY FORM: validation + AJAX quote
   ========================================================= */
(function initEnquiry() {
  const form = $('#enquiry-form');
  if (!form) return;

  const itemSel = $('#item');
  const dateInput = $('#collection-date');
  const resultBox = $('#enquiry-result');
  const submitBtn = $('button[type="submit"]', form);
  const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  const startOfToday = () => { const d = new Date(); d.setHours(0, 0, 0, 0); return d; };
  const toISO = d => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  const parseISO = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const fmtDate = d => `${DAY_NAMES[d.getDay()]}, ${d.getDate()} ${d.toLocaleString('en-ZA', { month: 'long' })} ${d.getFullYear()}`;

  // Restrict the date picker: today up to 90 days ahead
  const min = startOfToday();
  const max = new Date(min); max.setDate(max.getDate() + 90);
  dateInput.min = toISO(min);
  dateInput.max = toISO(max);

  // Fill the item <select> from the JSON file (dynamic content)
  loadProductData().then(data => {
    data.products.forEach(p => {
      itemSel.append(el('option', {
        text: `${p.name} (${p.priceFrom ? 'from ' : ''}${money(p.price)})`,
        attrs: { value: p.id }
      }));
    });
    const preset = new URLSearchParams(window.location.search).get('item');
    if (preset && data.products.some(p => p.id === preset)) itemSel.value = preset;
  }).catch(() => {
    itemSel.append(el('option', { text: 'Menu unavailable - please use the contact page', attrs: { value: '', disabled: '' } }));
  });

  const validateAll = attachValidation({
    'full-name': () => rule.name('full-name'),
    'email': () => rule.email('email'),
    'phone': () => rule.phone('phone', true),
    'enquiry-type': () => rule.required('enquiry-type', 'Please choose what you would like to know.'),
    'item': () => rule.required('item', 'Please choose an item.'),
    'quantity': () => {
      const raw = $('#quantity').value.trim();
      if (!raw) return 'Please enter a quantity.';
      const n = Number(raw);
      if (!Number.isInteger(n)) return 'Quantity must be a whole number.';
      if (n < 1 || n > 50) return 'Enter a quantity between 1 and 50.';
      return '';
    },
    'collection-date': () => {
      const v = dateInput.value;
      if (!v) return 'Please select a collection date.';
      const chosen = parseISO(v);
      if (Number.isNaN(chosen.getTime())) return 'Please enter a valid date.';
      if (chosen < startOfToday()) return 'Collection date cannot be in the past.';
      if (chosen > max) return 'Please choose a date within the next 90 days.';
      return '';
    },
    'message': () => ($('#message').value.length > 500 ? 'Notes must be 500 characters or fewer.' : '')
  });

  /** Business rules: returns an object describing price + availability. */
  function processEnquiry(data, v) {
    const product = data.products.find(p => p.id === v.item);
    const chosen = parseISO(v.date);
    const today = startOfToday();
    const leadDays = Math.round((chosen - today) / 86400000);
    const dayName = DAY_NAMES[chosen.getDay()];
    const isCollectionDay = data.collectionDays.includes(dayName);
    const needsLead = v.type === 'event' || v.qty >= 24 ? Math.max(data.minLeadDays, 7) : data.minLeadDays;

    const reasons = [];
    if (!isCollectionDay) reasons.push(`We only offer collection on ${data.collectionDays.map(d => d + 's').join(' and ')}.`);
    if (leadDays < needsLead) reasons.push(`This order needs at least ${needsLead} days' notice.`);
    if (v.qty > product.maxPerWeekend) reasons.push(`We bake a maximum of ${product.maxPerWeekend} of this item each weekend.`);

    // Suggest the next date that would work
    let suggestion = null;
    const probe = new Date(today);
    probe.setDate(probe.getDate() + needsLead);
    for (let i = 0; i < 21 && !suggestion; i++) {
      if (data.collectionDays.includes(DAY_NAMES[probe.getDay()])) suggestion = new Date(probe);
      probe.setDate(probe.getDate() + 1);
    }

    const subtotal = product.price * v.qty;
    const discountApplies = v.qty >= data.bulkThreshold && product.category !== 'boxes';
    const discount = discountApplies ? subtotal * data.bulkDiscount : 0;

    return { product, chosen, available: reasons.length === 0, reasons, suggestion, subtotal, discount, total: subtotal - discount, discountApplies, data };
  }

  function row(label, value, extraClass) {
    return el('div', { class: 'result-row' },
      el('dt', { text: label }),
      el('dd', { class: extraClass || '', text: value }));
  }

  function renderResult(v, r) {
    const ref = 'SC-' + toISO(new Date()).replace(/-/g, '') + '-' + Math.random().toString(36).slice(2, 6).toUpperCase();
    const list = el('dl', { class: 'result-list' });
    const children = [];

    children.push(el('h2', { text: v.type === 'allergens' ? 'Ingredients and allergens' : 'Your enquiry response', attrs: { id: 'result-title' } }));
    children.push(el('p', { class: 'ref', text: `Reference: ${ref}` }));

    list.append(row('Item', r.product.name), row('Quantity', String(v.qty)));

    if (v.type === 'allergens') {
      list.append(row('Contains', r.product.allergens.join(', ')));
      children.push(list);
      children.push(el('p', { text: 'All items are baked in a home kitchen that also handles gluten, dairy, eggs, soy and tree nuts, so we cannot guarantee any item is free from traces of these.' }));
    } else {
      list.append(row('Collection date', fmtDate(r.chosen)));
      list.append(row('Availability', r.available ? 'Available' : 'Not available on this date', r.available ? 'ok' : 'bad'));
      if (v.type !== 'availability') {
        list.append(row('Subtotal', money(r.subtotal)));
        if (r.discountApplies) list.append(row(`Bulk discount (${r.data.bulkDiscount * 100}%)`, '- ' + money(r.discount)));
        list.append(row('Estimated total', money(r.total) + (r.product.priceFrom ? ' (from)' : ''), 'total'));
      }
      children.push(list);

      if (!r.available) {
        const ul = el('ul', { class: 'reasons' }, r.reasons.map(t => el('li', { text: t })));
        children.push(ul);
        if (r.suggestion) {
          children.push(el('p', { text: `The next collection date we can offer is ${fmtDate(r.suggestion)}. Change the date above and resubmit to confirm.` }));
        }
      } else {
        children.push(el('p', { text: 'Great news, we can bake this for you. We will confirm your order by email or phone within 24 hours. Payment is made on collection.' }));
      }
      if (r.product.priceFrom) children.push(el('p', { class: 'small', text: 'Seasonal specials vary in price by flavour; we will confirm the exact amount.' }));
    }

    resultBox.replaceChildren(...children);
    resultBox.hidden = false;
    resultBox.focus();
    resultBox.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'start' });
  }

  form.addEventListener('submit', async e => {
    e.preventDefault();
    if (!validateAll()) { resultBox.hidden = true; return; }

    const values = {
      name: $('#full-name').value.trim(),
      type: $('#enquiry-type').value,
      item: itemSel.value,
      qty: Number($('#quantity').value),
      date: dateInput.value
    };

    // AJAX: fetch the product/price data asynchronously, no page reload
    submitBtn.disabled = true;
    submitBtn.textContent = 'Checking\u2026';
    try {
      const data = await loadProductData();
      renderResult(values, processEnquiry(data, values));
    } catch (err) {
      resultBox.replaceChildren(
        el('h2', { text: 'Something went wrong' }),
        el('p', { text: 'We could not check prices just now. Please try again, or send us a message on the contact page.' })
      );
      resultBox.hidden = false;
    } finally {
      submitBtn.disabled = false;
      submitBtn.textContent = 'Get My Quote';
    }
  });
})();

/* =========================================================
   6. CONTACT FORM: validation + compiled email
   ========================================================= */
(function initContactForm() {
  const form = $('#contact-form');
  if (!form) return;

  const preview = $('#email-preview');
  const recipient = form.dataset.recipient;

  const validateAll = attachValidation({
    'c-name': () => rule.name('c-name'),
    'c-email': () => rule.email('c-email'),
    'c-phone': () => rule.phone('c-phone', false),
    'c-type': () => rule.required('c-type', 'Please choose a type of message.'),
    'c-message': () => {
      const v = $('#c-message').value.trim();
      if (v.length < 10) return 'Please enter a message of at least 10 characters.';
      if (v.length > 1000) return 'Message must be 1000 characters or fewer.';
      return '';
    }
  });

  function compose() {
    const name = $('#c-name').value.trim();
    const email = $('#c-email').value.trim();
    const phone = $('#c-phone').value.trim();
    const type = $('#c-type').value;
    const message = $('#c-message').value.trim();
    const subject = `[Sweet Crumb website] ${type} from ${name}`;
    const body = [
      'Hello Sweet Crumb,',
      '',
      message,
      '',
      '--- Contact details ---',
      `Name: ${name}`,
      `Email: ${email}`,
      `Phone: ${phone || 'not provided'}`,
      `Message type: ${type}`
    ].join('\n');
    return { subject, body };
  }

  function row(label, value) {
    return el('div', { class: 'result-row' }, el('dt', { text: label }), el('dd', { text: value }));
  }

  form.addEventListener('submit', e => {
    e.preventDefault();
    if (!validateAll()) { preview.hidden = true; return; }

    const { subject, body } = compose();
    const mailto = `mailto:${recipient}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;

    const openLink = el('a', { class: 'btn', text: 'Open in my email app', attrs: { href: mailto } });
    const copyBtn = el('button', { class: 'btn btn-outline', text: 'Copy email text', attrs: { type: 'button' } });
    const editBtn = el('button', { class: 'btn btn-outline', text: 'Edit message', attrs: { type: 'button' } });
    const status = el('p', { class: 'small', attrs: { role: 'status' } });

    copyBtn.addEventListener('click', async () => {
      try {
        await navigator.clipboard.writeText(`To: ${recipient}\nSubject: ${subject}\n\n${body}`);
        status.textContent = 'Copied to clipboard.';
      } catch (err) {
        status.textContent = 'Could not copy automatically. Please select the text and copy it manually.';
      }
    });
    editBtn.addEventListener('click', () => { preview.hidden = true; $('#c-message').focus(); });

    preview.replaceChildren(
      el('h2', { text: 'Your email is ready' }),
      el('p', { text: 'Check the details below, then open it in your email app to send it.' }),
      el('dl', { class: 'result-list' }, row('To', recipient), row('Subject', subject)),
      el('pre', { class: 'email-body', text: body }),
      el('div', { class: 'card-actions' }, openLink, copyBtn, editBtn),
      status
    );
    preview.hidden = false;
    preview.focus();
  });
})();

/* =========================================================
   7. CONTACT PAGE: interactive map (Leaflet + OpenStreetMap)
   ========================================================= */
(function initMap() {
  const mapEl = $('#map');
  if (!mapEl) return;

  if (typeof L === 'undefined') {
    mapEl.append(el('p', { class: 'error-note', text: 'The interactive map could not be loaded. Our collection points are in Sandton (Saturdays) and Randburg (Sundays).' }));
    return;
  }

  const points = {
    northside: { name: 'Collection Point 1: Northside', address: '12 Oak Avenue, Northside, 2196', hours: 'Saturdays, 08:00 \u2013 12:00', coords: [-26.1076, 28.0567] },
    riverdale: { name: 'Collection Point 2: Riverdale', address: '45 Willow Street, Riverdale, 2192', hours: 'Sundays, 09:00 \u2013 13:00', coords: [-26.0936, 28.0064] }
  };

  const map = L.map(mapEl, { scrollWheelZoom: false }).setView([-26.1, 28.03], 12);
  L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    maxZoom: 19,
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
  }).addTo(map);

  const markers = {};
  Object.entries(points).forEach(([key, p]) => {
    const popup = el('div', {},
      el('strong', { text: p.name }), el('br'),
      document.createTextNode(p.address), el('br'),
      document.createTextNode(p.hours));
    markers[key] = L.marker(p.coords, { title: p.name, alt: p.name }).addTo(map).bindPopup(popup);
  });
  map.fitBounds(L.latLngBounds(Object.values(points).map(p => p.coords)).pad(0.4));

  $$('[data-focus-map]').forEach(btn => {
    btn.addEventListener('click', () => {
      const key = btn.dataset.focusMap;
      mapEl.scrollIntoView({ behavior: prefersReducedMotion ? 'auto' : 'smooth', block: 'center' });
      map.flyTo(points[key].coords, 15, { animate: !prefersReducedMotion });
      markers[key].openPopup();
    });
  });
})();

/* =========================================================
   8. ABOUT PAGE: tabs, accordion, lightbox
   ========================================================= */
(function initTabs() {
  const wrap = $('#about-tabs');
  if (!wrap) return;
  const tabs = $$('[role="tab"]', wrap);
  const panels = $$('[role="tabpanel"]', wrap);

  function select(tab, focus) {
    tabs.forEach(t => {
      const active = t === tab;
      t.setAttribute('aria-selected', String(active));
      t.tabIndex = active ? 0 : -1;
    });
    panels.forEach(p => { p.hidden = p.id !== tab.getAttribute('aria-controls'); });
    if (focus) tab.focus();
  }

  tabs.forEach((tab, i) => {
    tab.addEventListener('click', () => select(tab, false));
    tab.addEventListener('keydown', e => {
      let next = null;
      if (e.key === 'ArrowRight') next = tabs[(i + 1) % tabs.length];
      if (e.key === 'ArrowLeft') next = tabs[(i - 1 + tabs.length) % tabs.length];
      if (e.key === 'Home') next = tabs[0];
      if (e.key === 'End') next = tabs[tabs.length - 1];
      if (next) { e.preventDefault(); select(next, true); }
    });
  });
})();

(function initAccordion() {
  const acc = $('#faq');
  if (!acc) return;
  $$('button[aria-controls]', acc).forEach(btn => {
    btn.addEventListener('click', () => {
      const panel = document.getElementById(btn.getAttribute('aria-controls'));
      const open = btn.getAttribute('aria-expanded') === 'true';
      // Close the others so only one answer is open at a time
      $$('button[aria-controls]', acc).forEach(other => {
        other.setAttribute('aria-expanded', 'false');
        document.getElementById(other.getAttribute('aria-controls')).classList.remove('is-open');
      });
      if (!open) {
        btn.setAttribute('aria-expanded', 'true');
        panel.classList.add('is-open');
      }
    });
  });
})();

(function initLightbox() {
  const dialog = $('#lightbox');
  if (!dialog) return;
  const items = $$('.gallery-item');
  const img = $('#lightbox-img');
  const caption = $('#lightbox-caption');
  let index = 0;

  function show(i) {
    index = (i + items.length) % items.length;
    const { full, caption: cap } = items[index].dataset;
    img.src = full;
    img.alt = cap;
    caption.textContent = `${cap} (${index + 1} of ${items.length})`;
  }

  items.forEach((btn, i) => btn.addEventListener('click', () => { show(i); dialog.showModal(); }));
  $('.lb-prev', dialog).addEventListener('click', () => show(index - 1));
  $('.lb-next', dialog).addEventListener('click', () => show(index + 1));
  dialog.addEventListener('click', e => {
    if (e.target === dialog || e.target.closest('[data-close]')) dialog.close();
  });
  dialog.addEventListener('keydown', e => {
    if (e.key === 'ArrowLeft') show(index - 1);
    if (e.key === 'ArrowRight') show(index + 1);
  });
})();
