# Sweet Crumb Home Bakery — Website (WEDE5020, Part 3)

## Project Overview
A 5-page website for Sweet Crumb Home Bakery, a hypothetical home-based bakery
in Johannesburg specialising in handmade chocolate croissants. Part 1 built the
HTML structure, Part 2 added CSS styling and responsive design, and **Part 3
adds JavaScript functionality, SEO, enhanced forms and deployment**.

## Student Information
- Full Name: Olerato Owethu Selepe
- Student Number: ST10511014
- Group: 1

## Links
- Live website: https://sweetcrumb.netlify.app  *(replace with your deployed URL)*
- GitHub repository: *(add your repository link)*

## Website Goals and Objectives
- Move from informal social-media ordering to a professional online presence.
- Let customers browse the menu, check prices and availability, and submit structured pre-orders/enquiries.
- Build trust through clear information about the baker, ingredients, and collection points.
- Be found by local customers through search engines (SEO).

## Key Features and Functionality
- Responsive 5-page site: Home, About, Menu, Enquiry (order form), Contact (plus a custom 404 page).
- **Dynamic menu:** products are loaded from `data/products.json` with `fetch()` and rendered with DOM methods. Visitors can search, filter by category and sort by price/name.
- **Quick-view modal** (native `<dialog>`) showing allergens and weekend limits for each product.
- **Tabs** (Story / Mission / Vision), **accordion** FAQ and a **gallery with lightbox** (keyboard and arrow navigation) on the About page.
- **Interactive map** (Leaflet + OpenStreetMap) with both collection points on the Contact page.
- **Animations:** scroll-reveal sections, hero entrance, accordion/tab transitions, back-to-top button. All respect `prefers-reduced-motion`.
- **Enquiry form** with full validation and an AJAX price/availability response (see below).
- **Contact form** with validation that compiles the details into an email addressed to the recipient set in the code.
- Accessible, mobile-friendly navigation (real `<button>` hamburger with `aria-expanded`, skip link, visible focus styles).
- External stylesheet using CSS custom properties, CSS Grid and Flexbox, three responsive tiers, and responsive images (`srcset`/`sizes`/`<picture>`).

## Part 3 Details

### 1. JavaScript enhancements (`js/script.js`)
| Requirement | Implementation |
|---|---|
| Interactive elements | Accordion (FAQ), tabs, modal quick-view, lightbox (all vanilla JavaScript, no framework needed) |
| Interactive map | Leaflet + OpenStreetMap with markers/popups; "Show on map" buttons fly to each collection point |
| Animations/transitions | CSS transitions + IntersectionObserver scroll-reveal, CSS keyframe entrance animations |
| Advanced DOM manipulation | A small `el()` builder creates elements with `createElement`/`replaceChildren` (no `innerHTML`), dynamic ARIA updates, live result panels, dynamically created back-to-top button and email preview |
| Gallery + lightbox | About page gallery opens a `<dialog>` lightbox with previous/next, arrow keys, Esc and click-outside to close |
| Dynamic content | Product cards (home page favourites and full menu) and the enquiry item list are built from `data/products.json` |
| Search/filter/sort | Menu page: live text search (debounced), category filter and sort (price, name); URL parameters pre-fill the controls |

### 2. SEO
**On-page**
- Keyword research: target phrases were *chocolate croissants Johannesburg*, *home bakery*, *pre-order croissants*, *almond croissant* and *croissant box*; they are used naturally in titles, headings, descriptions and body copy.
- Unique `<title>` and `<meta name="description">` on every page, plus canonical URL, Open Graph and Twitter card tags.
- One `<h1>` per page and a logical H2/H3 hierarchy.
- Images use descriptive file names (e.g. `almond-croissant-800.jpg`), meaningful `alt` text, explicit `width`/`height` and `loading="lazy"`.
- Clean, descriptive URLs and consistent internal linking (nav, footer, calls to action, in-text links between pages).
- Mobile-friendly: viewport meta tag and responsive layout with tablet and mobile breakpoints.
- Structured data: JSON-LD `Bakery` schema (opening hours, price range, area served) on the home page for local search.

**Off-page**
- Backlinks: plan is to list the bakery on local directories (e.g. Google Business Profile, local food/community Facebook groups) and ask school fundraiser partners to link to the site.
- Social media: footer links to Instagram, Facebook and TikTok and Open Graph tags so shared links show a preview image and description.
- Local SEO: Johannesburg/Sandton/Randburg wording in content, structured data with area served, and map-based collection points.

**Additional**
- `robots.txt` (allows crawling, blocks `/data/`, points to the sitemap).
- `sitemap.xml` listing all five pages.
- Page speed: images resized and the hero image compressed, oversized originals removed from the deployed folder, lazy-loaded images, `defer` on scripts, font preconnect, long cache headers for images (`_headers`).
- Security: Content-Security-Policy meta tag, `rel="noopener noreferrer"` on external links, Subresource Integrity on the Leaflet files, no `innerHTML` with user data, security headers in `_headers` (X-Content-Type-Options, X-Frame-Options, Referrer-Policy, Permissions-Policy), and HTTPS from the hosting platform.

### 3. Forms and validation
- **enquiry.html** — asks for name, email, phone, enquiry type (price quote, availability, allergens, event/bulk order), item, quantity, collection date and notes. After validation the script uses AJAX (`fetch` + `async/await`) to load the product data without reloading the page and shows a response containing the **cost** (with a 5% discount on 12+ non-box items), **availability** (collection only on Saturdays/Sundays, at least 2 days' notice or 7 days for events/large orders, weekend limits per item), the next available date if the chosen date does not work, and allergen information. Each response has a reference number.
- **contact.html** — asks for name, email, optional phone, message type and a full message. Once validated, the details are compiled into an email shown in a preview with **Open in my email app** (a `mailto:` link to the recipient defined in the form's `data-recipient` attribute), **Copy email text** and **Edit message** buttons.
- Form elements: `input` (text, email, tel, number, date, search), `select`, `textarea`, labels linked with `for`/`id`.
- HTML5 validation attributes (`required`, `minlength`, `maxlength`, `min`, `max`, `type`) as a baseline, plus JavaScript validation: letters-only names, email pattern, South African phone format (`082 123 4567` / `+27 82 123 4567`), whole-number quantity 1–50, date not in the past and within 90 days, character limits.
- Inline error messages appear on blur and while typing, the first invalid field receives focus, and `aria-invalid`/`aria-describedby` keep errors accessible to screen readers.
- Form submission: both forms define an `action` attribute (`enquiry.html` via GET and `mailto:` respectively) as the no-JavaScript fallback; with JavaScript the submit event is handled asynchronously instead.
- Note: the prices, discount, notice period and weekend limits are the bakery's business rules for this project and live in `data/products.json`, so they can be changed without touching the code.

### 4. Deployment
The site is static and can be hosted on Netlify (drag-and-drop the project folder, or connect the GitHub repository with no build command and publish directory `/`) or GitHub Pages. After deploying, replace `https://sweetcrumb.netlify.app` in `sitemap.xml`, `robots.txt`, the `canonical`/Open Graph tags and the JSON-LD with the real URL.

### 5. Testing notes
Tested in Chromium at desktop (1100px) and mobile (375px) widths: menu search/filter/sort, quick view, enquiry validation and quote logic (available and unavailable dates), contact email compilation, tabs, accordion, lightbox and mobile menu. Because the menu data is loaded with `fetch()`, open the site through a local server (e.g. VS Code Live Server) or the deployed URL rather than double-clicking the HTML files.

## Screenshot Evidence (Desktop / Tablet / Mobile)
> **To do before submission:** add screenshots of the site at desktop
> (≥1024px), tablet (~768px), and mobile (~375px) widths — for at least the
> Home and Menu pages — using your browser's DevTools device toolbar, and
> place them here (e.g. in a `screenshots/` folder) with a short caption for
> each, as required by the brief.

- Desktop (1024px+): _add screenshot(s) here_
- Tablet (~768px): _add screenshot(s) here_
- Mobile (~375px): _add screenshot(s) here_

## Sitemap
```
index.html      -> Home
about.html      -> About Us (tabs, gallery, FAQ)
products.html   -> Menu / Products (dynamic, searchable)
enquiry.html    -> Order / Enquiry form (AJAX quote)
contact.html    -> Contact + interactive map + email form
404.html        -> Custom not-found page
```

## File and Folder Structure
```
/
├── index.html
├── about.html
├── products.html
├── enquiry.html
├── contact.html
├── 404.html
├── robots.txt
├── sitemap.xml
├── _headers                (Netlify security + caching headers)
├── css/
│   └── style.css
├── js/
│   └── script.js
├── data/
│   └── products.json       (menu, prices, availability rules)
├── images/
│   ├── hero-croissant.jpg
│   ├── baker-placeholder-400/800/1200.jpg
│   ├── choco-croissants-400/800/1200.jpg
│   ├── almond-croissant-400/800/1200.jpg
│   ├── seasonal-special-400/800/1200.jpg
│   └── croissant-box-400/800/1200.jpg
└── README.md
```

## Changelog

### Part 3 — Functionality, SEO and forms (new entries)
- v3.0 — Added `data/products.json` and JavaScript that loads products with `fetch()`; the home page "favourites" and the full menu are now generated dynamically with DOM methods.
- v3.1 — Added search, category filter and sort to the Menu page, a results counter (`aria-live`), an empty state with a "Clear filters" button, and a quick-view modal using `<dialog>`.
- v3.2 — About page: converted Story/Mission/Vision into accessible tabs (arrow-key navigation), added an FAQ accordion and a photo gallery with a lightbox (previous/next, keyboard and click-outside support).
- v3.3 — Contact page: replaced the two Google Maps iframes with a Leaflet/OpenStreetMap map showing both collection points with popups and "Show on map" buttons.
- v3.4 — Added animations: scroll-reveal sections, hero entrance, accordion/tab/dialog transitions and a back-to-top button, all disabled for users who prefer reduced motion.
- v3.5 — Rebuilt the enquiry form with email, phone and enquiry-type fields, a dynamically populated item list and a date picker limited to the next 90 days. JavaScript validation covers names, email, South African phone numbers, quantity and dates with inline, accessible error messages.
- v3.6 — Enquiry form now responds without a page reload (AJAX/`fetch`) with the price (including bulk discount), availability, next available collection date and allergen information.
- v3.7 — Contact form now includes phone and message type; validated details are compiled into an email preview with an "Open in my email app" `mailto:` link to the recipient defined in the code, plus copy/edit options.
- v3.8 — SEO: unique titles/descriptions, keywords, canonical URLs, Open Graph/Twitter tags, JSON-LD `Bakery` structured data, descriptive alt text, social links in the footer, `robots.txt` and `sitemap.xml`.
- v3.9 — Performance and security: compressed the hero image and removed the unused full-size originals (about 14 MB), added image `width`/`height`, `defer` on scripts, font preconnect, Content-Security-Policy, `rel="noopener noreferrer"`, SRI on Leaflet, and a `_headers` file for Netlify.
- v3.10 — Added a custom `404.html` page, a deployment section and testing notes to this README.

### Part 2 feedback corrections (applied in Part 3)
> Edit these entries so they match the exact comments you received on Part 2.
- v3.fb1 — Fonts: the stylesheet referenced *Playfair Display* and *Open Sans* but never loaded them, so browsers fell back to default fonts. Added the Google Fonts links (`display=swap`) on every page.
- v3.fb2 — Navigation accessibility: replaced the checkbox/label hamburger (not keyboard accessible) with a `<button>` using `aria-expanded` and `aria-controls`; added a "Skip to main content" link and wrapped page content in `<main>`.
- v3.fb3 — Colour contrast: darkened the gold price text (`#c9a24b` to `#8a6a1f`) so prices meet WCAG AA contrast on the white cards.
- v3.fb4 — Contact page: the maps used generic "Sandton" and "Randburg" searches that did not match the written collection addresses; both collection points are now shown as labelled markers with their address and hours.
- v3.fb5 — Removed inline `style` attributes from the HTML (moved to CSS classes), added `width`/`height` to images to prevent layout shift, and fixed duplicated "Part 1" wording in the old changelog ordering by listing entries newest first.
- v3.fb6 — Footer expanded to include navigation, social links and the business description on every page.

### Part 2 — CSS styling and responsive design
- v2.0 — Added a formal CSS reset (`box-sizing`, margin/padding reset, list
  style reset) and a `rem`-based typography scale via CSS custom properties.
- v2.1 — Converted fixed pixel spacing (padding/margin on buttons, cards,
  forms, and the footer) to relative `em`/`rem` units so spacing scales with
  font size; retained `%`-based widths on form fields and embedded maps.
- v2.2 — Added `:focus-visible` outline styles across links, buttons, and
  form fields, plus `:active` states on the primary button and nav links, to
  improve keyboard accessibility and interactive feedback.
- v2.3 — Added `box-shadow` and a subtle lift transform on menu/card hover,
  and refined the CTA button's `hover`/`active` shadow states.
- v2.4 — Restructured the responsive breakpoints into a clear three-tier
  system: desktop (default), tablet (`max-width: 1024px`), and mobile
  (`max-width: 640px`), with breakpoint-specific hero, grid, and navigation
  adjustments.
- v2.5 — Generated and wired up responsive image variants (400w/800w/1200w)
  for the four menu photos and the baker portrait, using `srcset`/`sizes` on
  the menu images and a `<picture>` element with `<source media>` for the
  baker portrait on the About page.

### Part 1 (prior submission)
- v0.1 — Initial HTML structure and navigation for all 5 pages.
- v0.2 — CSS styling applied (colour scheme, typography, responsive layout).
- v0.3 — JavaScript form validation added for enquiry and contact forms.
- v0.4 — Placeholder images added; replace with final licensed/original photography before final submission.

## References
- W3Schools, 2026. HTML Forms. Available at: https://www.w3schools.com/html/html_forms.asp
- MDN Web Docs, 2026. Client-side form validation. Available at: https://developer.mozilla.org/en-US/docs/Learn/Forms/Form_validation
- Google, 2026. Google Maps Embed (no API key). Available at: https://www.google.com/maps
- MDN Web Docs, 2026. Using CSS custom properties (variables). Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/Using_CSS_custom_properties
- MDN Web Docs, 2026. Responsive images. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Guides/Responsive_images
- MDN Web Docs, 2026. CSS Grid Layout. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_grid_layout
- MDN Web Docs, 2026. Flexbox. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_flexible_box_layout
- MDN Web Docs, 2026. Using media queries. Available at: https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_media_queries/Using_media_queries
- CSS-Tricks, 2026. A Complete Guide to CSS Media Queries. Available at: https://css-tricks.com/a-complete-guide-to-css-media-queries/
- MDN Web Docs, 2026. The dialog element. Available at: https://developer.mozilla.org/en-US/docs/Web/HTML/Element/dialog
- MDN Web Docs, 2026. Using the Fetch API. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Fetch_API/Using_Fetch
- MDN Web Docs, 2026. Intersection Observer API. Available at: https://developer.mozilla.org/en-US/docs/Web/API/Intersection_Observer_API
- MDN Web Docs, 2026. ARIA: tab role and Accordion patterns. Available at: https://developer.mozilla.org/en-US/docs/Web/Accessibility/ARIA/Reference/Roles/tab_role
- W3C, 2026. ARIA Authoring Practices Guide: Tabs and Accordion patterns. Available at: https://www.w3.org/WAI/ARIA/apg/patterns/
- Leaflet, 2026. Leaflet Quick Start Guide. Available at: https://leafletjs.com/examples/quick-start/
- OpenStreetMap Foundation, 2026. Copyright and licence. Available at: https://www.openstreetmap.org/copyright
- Google, 2026. SEO Starter Guide. Available at: https://developers.google.com/search/docs/fundamentals/seo-starter-guide
- Google, 2026. Introduction to robots.txt and Build and submit a sitemap. Available at: https://developers.google.com/search/docs/crawling-indexing
- Schema.org, 2026. Bakery. Available at: https://schema.org/Bakery
- MDN Web Docs, 2026. Content Security Policy (CSP). Available at: https://developer.mozilla.org/en-US/docs/Web/HTTP/CSP
- Netlify, 2026. Custom headers and Deploy sites. Available at: https://docs.netlify.com/
- GitHub, 2026. GitHub Pages documentation. Available at: https://docs.github.com/en/pages
